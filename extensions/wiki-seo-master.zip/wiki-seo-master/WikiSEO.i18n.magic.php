<?php
/**
 * Internationalisation file for magic words.
 *
 * @file
 */

$magicWords = [];

/**
 * English (English)
 */
$magicWords['en'] = [
	'seo' => [ 0, 'seo' ],
];
